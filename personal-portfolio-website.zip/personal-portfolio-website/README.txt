PERSONAL PORTFOLIO WEBSITE

FILES
- index.html: website content and structure
- style.css: colours, layout, responsive design and styling
- script.js: mobile navigation and current year

HOW TO OPEN
1. Extract the ZIP file.
2. Open the personal-portfolio-website folder.
3. Double-click index.html. It will open in your browser.
4. To edit the website, open the folder in Visual Studio Code.

IMPORTANT PERSONALISATION
1. In index.html, replace "Sharmi" if you want a different display name.
2. Replace your-email@example.com with your real email address.
3. Replace the GitHub link https://github.com/ with your own profile URL.
4. Update skills and project descriptions as your experience grows.
5. Do not list a skill as advanced unless you can confidently demonstrate it.

PUBLISH WITH GITHUB PAGES
1. Create a public GitHub repository named my-personal-portfolio.
2. Upload index.html, style.css and script.js to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and / (root), then Save.
6. Wait for GitHub Pages to publish the website. The published link will appear in Settings > Pages.

The website uses Google Fonts when an internet connection is available; system fonts are used as a fallback.
